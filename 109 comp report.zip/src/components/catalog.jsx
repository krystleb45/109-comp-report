import { useEffect, useState } from "react";

import "./catalog.css";
import Item from "./item";
import DataService from "../services/dataService";

const Catalog = () => {
  const [itemList, setItemList] = useState([]);
  const [categories, setCategories] = useState([]);
  const [itemsToDisplay, setItemsToDisplay] = useState([]);

  const loadCatalog = async () => {
    let service = new DataService();
    let catalog = await service.getCatalog();

    //(get server from front end)
    //find the list of unique categories
    /*let cats = [];
    for (let i = 0; i < catalog.length; i++) {
      let prod = catalog[i];

      if (!cats.includes(prod.category)) {
        cats.push(prod.category);
      }
    }*/

    //get the categories from the server (backend)
    let cats = await service.getCategories();

    console.log("unique cats", cats);
    setCategories(cats);

    setItemList(catalog);
    setItemsToDisplay(catalog);
  };
  const handleFilter = (cat) => {
    console.log("You clicked the button", cat);
    //clear previous data
    setItemsToDisplay([]);
    //filter from the itemList inot itemsToDisplay

    let results = [];
    for (let i = 0; i < itemList.length; i++) {
      let prod = itemList[i];
      if (prod.category === cat) {
        results.push(prod);
      }
    }
    setItemsToDisplay(results);
  };

  const resetFilter = () => {
    setItemsToDisplay(itemList);
  };

  useEffect(() => {
    loadCatalog();
    //do something else Cmd + P
  }, []);

  return (
    <div className="catalog">
      <h1>Our amazing Catalog</h1>
      <h3>Currently have {itemList.length} products</h3>

      <div className="filters">
        <button onClick={resetFilter} className="btn btn-sm btn-dark">
          All
        </button>
        {categories.map((cat) => (
          <button
            onClick={() => {
              handleFilter(cat);
            }}
            className="btn btn-sm btn-info"
          >
            {cat}
          </button>
        ))}
      </div>

      {itemsToDisplay.map((prod) => (
        <Item data={prod}></Item>
      ))}
    </div>
  );
};
export default Catalog;
