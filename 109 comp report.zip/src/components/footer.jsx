import "./footer.css";

function Footer() {
  return (
    <div className="footer">
      <h5>Electronics store. All Rights Reserved. 2021</h5>
      <h6>Krystle Berry</h6>
    </div>
  );
}

export default Footer;
