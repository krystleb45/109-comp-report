import React, {useState} from "react";
import StoreContext from "./storeContext";


const GlobalContext = (props) => {
    
    const [cart, setCart] = useState([]);
    const [user, setUser] = useState({
        id: 132535,
        name: "Krystle Berry",
        email: "krystle.monet@gmail.com",
    });

const addProductToCart = (proudct) => {
    console.log("Add to cart");

    let copy = [...cart, proudct];
    setCart(copy);
}

const removeProdFromCart = (productID) => {
    console.log("Removing Prod");
}
/**left side is the abstract description for data/funs
 * right side is the implementation for data/fns
 * when someone calls the abstract, will get the implementatioin
 */

return (
    <StoreContext.Provider
        value={{
            cart: cart,
            user: user, 
            addProductToCart: addProductToCart,
            removeProdFromCart: removeProdFromCart,
        }}
    >
        {props.children}
    </StoreContext.Provider>
    );
};

export default GlobalContext;